export const ORGANIZATION = '/';
export const PROFILE = '/profile';
