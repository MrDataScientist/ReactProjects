import Comments from './CommentList';

export default Comments;
