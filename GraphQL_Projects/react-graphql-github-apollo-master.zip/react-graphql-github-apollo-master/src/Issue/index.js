import Issues from './IssueList';

export default Issues;
